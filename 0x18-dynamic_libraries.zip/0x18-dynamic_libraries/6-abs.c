#include "main.h"
/**
 *_abs - return deppend of sign of n
 *
 *Return: 0
 *@c: number for evaluate
 */
int _abs(int c)
{
	if (c < 0)
	{
		return (-c);
	}
	else
		return (c);
}
