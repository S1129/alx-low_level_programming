#ifndef _OPERATIONS_H
#define _OPERATIONS_H


int add(int a, int b);
int sub(int a, int b);
int mul(int a, int b);
int div(int a, int b);
int mod(int a, int b);
#endif
